/**
 * api.js
 * Centralised helpers for all Flask API calls.
 * The CRA proxy (set in package.json) forwards /api → http://localhost:5000
 */

const BASE = '/api';

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

/* ── Articles ──────────────────────────────────────── */

/** GET /api/articles?category=  →  array of article summaries */
export function getArticles(category = '') {
  const qs = category ? `?category=${encodeURIComponent(category)}` : '';
  return request(`/articles${qs}`);
}

/** GET /api/articles/<id>  →  single article with full content */
export function getArticle(id) {
  return request(`/articles/${id}`);
}

/** POST /api/articles  →  created article */
export function createArticle(data) {
  return request('/articles', { method: 'POST', body: JSON.stringify(data) });
}

/** PUT /api/articles/<id>  →  updated article */
export function updateArticle(id, data) {
  return request(`/articles/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}

/** DELETE /api/articles/<id>  →  { message } */
export function deleteArticle(id) {
  return request(`/articles/${id}`, { method: 'DELETE' });
}

/** GET /api/articles/search?q=  →  array of matching articles */
export function searchArticles(query) {
  return request(`/articles/search?q=${encodeURIComponent(query)}`);
}

/** GET /api/categories  →  array of category strings */
export function getCategories() {
  return request('/categories');
}
